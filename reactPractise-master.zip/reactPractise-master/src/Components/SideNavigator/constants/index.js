const GET_SIDENAV_ITEMS = 'sideNav/getItems';
const GET_SIDENAV_ITEMS_SUCCESS = 'sideNav/getItems_Success';
const GET_SIDENAV_ITEMS_FAILED = 'sideNav/getItems_Failed';

export { GET_SIDENAV_ITEMS, GET_SIDENAV_ITEMS_SUCCESS, GET_SIDENAV_ITEMS_FAILED };
